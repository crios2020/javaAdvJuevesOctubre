package clase03;

import java.io.InputStream;
import java.net.Socket;

public class ClienteMinimo {
    public static void main(String[] args) {
        try (
                Socket so=new Socket("192.168.0.3",5000);
                InputStream in=so.getInputStream();
        ){
            //byte[] bytes=in.readAllBytes();         //JDK 9
            //for(int a=0;a<bytes.length;a++) System.out.print((char)bytes[a]);
            for(byte b:in.readAllBytes()) System.out.print((char)b);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println();
    }
}
package clase03;
public class Clase03 {
    public static void main(String[] args) {
        
        /*
        
        Protocolo TCP/IP            Costoso             Seguro
        Protocolo UDP               Economico           Inseguro
        NewClass
        
        
        Protocolo TCP/IP
        
        Server                                  Client
        ---------------                         ---------------
        new ServerSocket(int port)              new Socket(String ip,int port);
        .accept()
        ---------------                         --------------- 
        InputStream         <--------------     OutputStream
        OutputStream        -------------->     InputStream
        ---------------                         --------------- 
        .close()                                .close()
        ---------------                         --------------- 
        
        BufferedInputStream - BufferedOutputStream: Stream de buffer
        DataInputStream - DataOutputStream: Stream de datos primitivos
        ObjectInputStream - ObjectOutputStream: Stream de objetos
        
        */
        
    }
    
}

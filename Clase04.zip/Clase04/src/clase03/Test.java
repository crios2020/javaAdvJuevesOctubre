package clase03;
public class Test{
	public static void main(String... args){
		// varargs jdk5
		//System.out.println("Chauu Mundo!!!");
		//String[] vector={"Hola","chau","java"};
		//metodo1(vector);
		//metodo2(vector);
		//metodo2("Hola","chau","java","Jueves");
		
		System.out.println("longitud de vector argumentos: "+args.length);
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
		
	}
	
	public static void metodo1(String[] args){
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}
	
	public static void metodo2(String... args){	
		for(int a=0;a<args.length;a++) System.out.println(args[a]);
	}
	public static void metodo3(String x,int... args){
	}
}

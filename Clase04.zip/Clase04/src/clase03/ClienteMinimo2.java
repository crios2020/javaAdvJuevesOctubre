package clase03;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClienteMinimo2 {
    public static void main(String[] args) {
        String line;
        try (
                BufferedReader in=new BufferedReader(
                new InputStreamReader(
                        new Socket("192.168.0.3",5000).getInputStream()));
        ) {
            
            
            //in.lines().forEach(x->System.out.println(x));
            //in.lines().forEach(System.out::println);
            
            
            //in
            //        .lines()
            //        .filter(linea->linea.equalsIgnoreCase("lunes."))
            //        .forEach(System.out::println);
            
            in
                    .lines()
                    .filter(linea->linea.endsWith("s."))
                    .forEach(System.out::println);
            
            //while((line=in.readLine())!=null){
            //    System.out.println(line);
            //}
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
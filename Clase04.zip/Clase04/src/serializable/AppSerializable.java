package serializable;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class AppSerializable {
    public static void main(String[] args) {
        File file=new File("datos.dat");
        
        //Serializado
        try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(file))){
            out.writeObject(new Persona("Juan","Perez",23));
            out.writeObject(new Persona("Laura","Perez",33));
            out.writeObject(new Persona("Lorena","Perez",23));
            out.writeObject(new Persona("Ricardo","Perez",24));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        //Deserializado
        try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(file))) {
            while(true){
                Persona p=(Persona)in.readObject();
                System.out.println(p);
            }
        } catch (EOFException e){ System.out.println("Fin del archivo!");
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
        /*
        COMPUTADORA 1                                COMPUTADORA 2
        
                            persona1.tojson()
        persona1        ---------------------------> Juan,Perez,33
        (Juan,Perez,33)
        
        
                        con Serializado
        persona1        --------------------------->  persona1
        (Juan,Perez,33)                               (Juan,Perez,33)
        
        */
    }
}

package chat;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapaDirecciones {
    public static synchronized Map<String,String>getMapa(){
        Map<String,String>mapa=Collections.synchronizedMap(new LinkedHashMap());
        mapa.put("Marcelo", "192.168.0.10");
        mapa.put("Carlos", "192.168.0.3");
        return mapa;
    }
}
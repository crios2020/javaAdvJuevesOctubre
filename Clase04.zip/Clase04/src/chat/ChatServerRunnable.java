package chat;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JTextArea;
public class ChatServerRunnable implements Runnable{
    private JTextArea txa;

    public ChatServerRunnable(JTextArea txa) {
        this.txa = txa;
    }
    private static String user="";
    @Override
    public void run() {
        try (ServerSocket ss=new ServerSocket(6000)) {
            while(true){
                try (Socket so=ss.accept();
                    BufferedReader in=new BufferedReader(
                            new InputStreamReader(so.getInputStream()));   
                     ) {
                    String ip=so.getInetAddress().getHostAddress();
                    MapaDirecciones.getMapa().forEach((k,v)->{
                        if(v.equals(ip)) user=k;
                    });
                    String mensaje=in.readLine();
                    txa.append(user+": "+mensaje+"\n");
                } catch (Exception ee) {
                    ee.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}

package ar.com.eduit.curso.java.adv.clase02;
public class ProgramaSaludar {
    public static void main(String[] args) {
        Saludo saludo=new Saludo();
        
        new Empleado("luis",saludo,false).start();
        new Empleado("ana",saludo,false).start();
        new Empleado("laura",saludo,false).start();
        new Empleado("victor",saludo,false).start();
        try{ Thread.sleep(2000); }catch(Exception e){}
        new Empleado("Jefe",saludo,true).start();
        
    }
}
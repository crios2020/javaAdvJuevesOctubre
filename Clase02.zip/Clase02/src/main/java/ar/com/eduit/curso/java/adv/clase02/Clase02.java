package ar.com.eduit.curso.java.adv.clase02;
public class Clase02 {
    public static void main(String[] args) {
        /*
        Ciclo de vida
        
        NEW                 RUNNABLE        TIMEWAITING         BLOCKED I/O     TERMINATED
        new Thread()        .start()        .sleep() .wait()                    .close()
        
        */
        
        HiloT hiloT1=new HiloT("hiloT 1");
        HiloT hiloT2=new HiloT("hiloT 2",800);
        HiloT hiloT3=new HiloT("hiloT 3",600);
        HiloT hiloT4=new HiloT("hiloT 4",400);
        
        System.out.println("hiloT1: "+hiloT1.getState());
        System.out.println("hiloT1: "+hiloT1.isAlive());
        
        hiloT1.setPriority(Thread.MIN_PRIORITY);
        hiloT4.setPriority(Thread.MAX_PRIORITY);
        
        try{
            //método join
            
            hiloT1.start();
            //hiloT1.join();
            hiloT2.start();
            //hiloT2.join();
            hiloT3.start();
            //hiloT3.join();
            hiloT4.start();
            //hiloT4.join();
            
            hiloT1.join();
            hiloT2.join();
            hiloT3.join();
            hiloT4.join();
   
        }catch(Exception e){}
        System.out.println("hiloT1: "+hiloT1.getState());
        System.out.println("hiloT1: "+hiloT1.isAlive());
        
        
        //try{ Thread.sleep(11000);} catch(Exception e){}
        
        System.out.println("-- Fin del programa --");
        System.out.println("hiloT1: "+hiloT1.getState());
        System.out.println("hiloT1: "+hiloT1.isAlive());
    }
}
package ar.com.eduit.curso.java.adv.clase02;
public class Empleado extends Thread {
    private String nombre;
    private Saludo saludo;
    private boolean esJefe;

    public Empleado(String nombre, Saludo saludo, boolean esJefe) {
        this.nombre = nombre;
        this.saludo = saludo;
        this.esJefe = esJefe;
    }
    
    @Override
    public void run(){
        saludo.saludar(nombre, esJefe);
    }
    
}
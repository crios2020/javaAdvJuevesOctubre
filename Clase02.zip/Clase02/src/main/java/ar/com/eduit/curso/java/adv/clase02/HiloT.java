package ar.com.eduit.curso.java.adv.clase02;
public class HiloT extends Thread{
    private String nombre;
    private int time=1000;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }
    
    public HiloT(String nombre, int time) {
        this.nombre = nombre;
        this.time = time;
    }
    
    @Override
    public void run(){
        //El método run es el unico de la clase que puede ejecutar en un hilo nuevo
        for(int a=1;a<=1000;a++){
            System.out.println(nombre+" "+a);
            //try { Thread.sleep(time); } catch(Exception e) { }
            //yield();
        }
    }
}

package ar.com.eduit.curso.java.adv.clase01;
public class HiloT extends Thread {
    //una clase que extiende Thread, puede trabajar en un hilo nuevo
    
    private String nombre;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public void run(){
        //El método run es el unico de la clase que puede ejecutar en un hilo nuevo
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            try { Thread.sleep(1000); } catch(Exception e) { }
        }
    }
    
}
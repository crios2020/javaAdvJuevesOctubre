package ar.com.eduit.curso.java.adv.clase02;
public class Cuenta {
    private float saldo=2000;
    public void debitar(float monto){
        System.out.println("Iniciando debito");
        synchronized(this){
            if(monto<=saldo){
                try {Thread.sleep(2000);} catch(Exception e){}
                saldo-=monto;
            }else{
                System.out.println("No hay fondos suficientes!");
            }
        }
        System.out.println("Operación Debito terminada.");
    }

    public float getSaldo() {
        return saldo;
    }
    
}

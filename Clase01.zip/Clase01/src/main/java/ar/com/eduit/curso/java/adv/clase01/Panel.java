package ar.com.eduit.curso.java.adv.clase01;

import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class Panel extends javax.swing.JFrame {
    private CronometroR crono;
    public Panel() {
        initComponents();
        
        //Date date=new Date();             //jdk 1
        //txtHora.setText(date.toString());
        
        //Calendar cal=Calendar.getInstance();        //jdk 1.1
        //txtHora.setText(cal.getTime().toString());
        
        //LocalDateTime - LocalDate - LocalTime       //jdk 8
        //LocalTime lt=LocalTime.now();
        //txtHora.setText(lt.toString());
        
        new Thread(new HoraR(txtHora)).start();
        
        crono=new CronometroR(txtCrono);
        new Thread(crono).start();
 
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtHora = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        txtCrono = new javax.swing.JTextField();
        btnCronoStart = new javax.swing.JButton();
        btnCronoPause = new javax.swing.JButton();
        btnCronoStop = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        btnCronoStart1 = new javax.swing.JButton();
        btnCronoPause1 = new javax.swing.JButton();
        btnCronoStop1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Panel");

        jLabel1.setText("Hora:");

        txtHora.setEditable(false);
        txtHora.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jLabel2.setText("Cronometro:");

        txtCrono.setEditable(false);
        txtCrono.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtCrono.setText("0");

        btnCronoStart.setText("Start");
        btnCronoStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCronoStartActionPerformed(evt);
            }
        });

        btnCronoPause.setText("Pause");
        btnCronoPause.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCronoPauseActionPerformed(evt);
            }
        });

        btnCronoStop.setText("Stop");
        btnCronoStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCronoStopActionPerformed(evt);
            }
        });

        jLabel3.setText("Music:");

        btnCronoStart1.setText("Play");
        btnCronoStart1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCronoStart1ActionPerformed(evt);
            }
        });

        btnCronoPause1.setText("Pause");
        btnCronoPause1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCronoPause1ActionPerformed(evt);
            }
        });

        btnCronoStop1.setText("Stop");
        btnCronoStop1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCronoStop1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addComponent(jSeparator2)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(82, 82, 82)
                        .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnCronoStart)
                            .addComponent(jLabel2))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(txtCrono, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(42, 42, 42)
                                .addComponent(btnCronoPause)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnCronoStop))))
                    .addComponent(jLabel3))
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(btnCronoStart1)
                .addGap(48, 48, 48)
                .addComponent(btnCronoPause1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnCronoStop1)
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCrono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCronoStart)
                    .addComponent(btnCronoPause)
                    .addComponent(btnCronoStop))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCronoStart1)
                    .addComponent(btnCronoPause1)
                    .addComponent(btnCronoStop1))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCronoStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCronoStartActionPerformed
        // Evento btnCronoStart
        crono.start();
    }//GEN-LAST:event_btnCronoStartActionPerformed

    private void btnCronoPauseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCronoPauseActionPerformed
        // Evento btnCronoPause
        crono.pause();
    }//GEN-LAST:event_btnCronoPauseActionPerformed

    private void btnCronoStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCronoStopActionPerformed
        // Evento btnCronoStop
        crono.stop();
    }//GEN-LAST:event_btnCronoStopActionPerformed

    private void btnCronoStart1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCronoStart1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCronoStart1ActionPerformed

    private void btnCronoPause1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCronoPause1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCronoPause1ActionPerformed

    private void btnCronoStop1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCronoStop1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCronoStop1ActionPerformed

    public static void main(String args[]) {
        new Panel().setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCronoPause;
    private javax.swing.JButton btnCronoPause1;
    private javax.swing.JButton btnCronoStart;
    private javax.swing.JButton btnCronoStart1;
    private javax.swing.JButton btnCronoStop;
    private javax.swing.JButton btnCronoStop1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTextField txtCrono;
    private javax.swing.JTextField txtHora;
    // End of variables declaration//GEN-END:variables
}

package ar.com.eduit.curso.java.adv.clase01;
import java.text.DecimalFormat;
import java.time.LocalTime;
import javax.swing.JTextField;
public class HoraR implements Runnable{
    private JTextField txt;

    public HoraR(JTextField txt) {
        this.txt = txt;
    }

    @Override
    public void run() {
        while(true){
            LocalTime lt=LocalTime.now();
            int hora=lt.getHour();
            int minutos=lt.getMinute();
            int segundos=lt.getSecond();
            
            DecimalFormat df=new DecimalFormat("00");
            txt.setText(df.format(hora)+":"+df.format(minutos)+":"+df.format(segundos));
            
            try { Thread.sleep(1000); } catch(Exception e) { }
        }
    }
    
}